"""
ANH HUYNH
CECS 274 
HAILU XU
11/1/20
"""

Drag the files from the .zip to your desktop
Run the .py using python IDLE 3.7 or 3.8

#3 was attempted for extra points; the rest of the assignment is completed