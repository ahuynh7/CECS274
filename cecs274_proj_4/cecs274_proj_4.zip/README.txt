"""
ANH HUYNH
CECS 274 
HAILU XU
11/23/20
"""

Drag the files from the .zip to your desktop
Run the .py using python IDLE 3.7 or 3.8