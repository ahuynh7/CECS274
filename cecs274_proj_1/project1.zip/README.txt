"""
ANH HUYNH
CECS 274 
HAILU XU
9/28/20
"""

Run the .py using python IDLE